# Modules
import pygame
import random
import os

# Module Initialization
pygame.font.init()
pygame.mixer.init()
pygame.display.init()

# Screen
screen_width, screen_height = 1000, 500
screen = pygame.display.set_mode((screen_width, screen_height))

# Title
pygame.display.set_caption("PandBoo")

# Icon
icon = pygame.image.load(os.path.join("Assets", "bamboo.png"))
pygame.display.set_icon(icon)

# Panda
panda_width, panda_height, panda_x, panda_y = 128, 128, 0, 372
panda = pygame.transform.scale(pygame.image.load(os.path.join("Assets", "panda.png")), (panda_width, panda_height))
panda_right = pygame.transform.scale(pygame.image.load(os.path.join("Assets", "panda_right.png")), (panda_width, panda_height))
panda_left = pygame.transform.scale(pygame.image.load(os.path.join("Assets", "panda_left.png")), (panda_width, panda_height))

# bamboo
bamboo_size, bamboo_x, bamboo_y = 64, random.randrange(1, 1001 - 64), -64
bamboo = pygame.transform.scale(pygame.image.load(os.path.join("Assets", "bamboo.png")), (bamboo_size, bamboo_size))

# Steak
steak_size, steak_x, steak_y = 64, random.randrange(1, 1001 - 64), -64
steak = pygame.transform.scale(pygame.image.load(os.path.join("Assets", "steak.png")), (steak_size, steak_size))

# Covers
blank_size = 256
blank = pygame.transform.scale(pygame.image.load(os.path.join("Assets", "blank.png")), (blank_size, blank_size))
background = pygame.image.load(os.path.join("Assets", "background.png"))
game_over = pygame.image.load(os.path.join("Assets", "game_over.png"))

# Game SFX
background_theme = pygame.mixer.music.load(os.path.join("Assets", "theme.wav"))
bamboo_collected = pygame.mixer.Sound(os.path.join("Assets", "bamboo_collected.wav"))
lost_life = pygame.mixer.Sound(os.path.join("Assets", "lost_life.wav"))
powerup = pygame.mixer.Sound(os.path.join("Assets", "powerup.wav"))
lost = pygame.mixer.Sound(os.path.join("Assets", "lost.wav"))

# Fonts
font = pygame.font.SysFont("Comic Sans MS", 40)

# Clock 
clock = pygame.time.Clock()

# Random game variables
FPS = 60
VELOCITY = 15
BLACK = (0, 0, 0)
RED = (255, 0, 0)
GREEN = (0, 255, 0)
BLUE = (0, 0, 255)
YELLOW = (255, 220, 0)
WHITE = (255, 255, 255)


# Steak spawning
def steak_spawn(panda_rect, steak_rect, B_VELOCITY):
    screen.blit(steak, (steak_rect.x, steak_rect.y))
    steak_rect.y += B_VELOCITY


# bamboo spawning
def bamboo_spawn(panda_rect, bamboo_rect, LIVES, B_VELOCITY):
    screen.blit(bamboo, (bamboo_rect.x, bamboo_rect.y))
    bamboo_rect.y += B_VELOCITY
    if LIVES == 0:
        screen.blit(game_over, (0, 0))


# Handle movement
def handle_movement(panda_rect):
    key_press = pygame.key.get_pressed()
    if key_press[pygame.K_d] or key_press[pygame.K_RIGHT]:
        screen.blit(blank, (panda_rect.x, panda_rect.y))
        panda_rect.x += VELOCITY
        screen.blit(panda_right, (panda_rect.x, panda_rect.y))
    if key_press[pygame.K_a] or key_press[pygame.K_LEFT]:
        screen.blit(blank, (panda_rect.x, panda_rect.y))
        panda_rect.x -= VELOCITY
        screen.blit(panda_left, (panda_rect.x, panda_rect.y))
    if panda_rect.x < 0:
        panda_rect.x += VELOCITY
    if panda_rect.x > 1000 - panda_rect.w:
        panda_rect.x -= VELOCITY


# Blit onto Screen
def draw(panda_rect, bamboo_rect, steak_rect, SCORE, LIVES, B_VELOCITY):
    screen.blit(background, (0, 0))
    screen.blit(panda, (panda_rect.x, panda_rect.y))
    handle_movement(panda_rect)
    bamboo_spawn(panda_rect, bamboo_rect, LIVES, B_VELOCITY)
    steak_spawn(panda_rect, steak_rect, B_VELOCITY)
    SCORE_txt = font.render(f"SCORE: {SCORE}", True, BLUE)
    screen.blit(SCORE_txt, (0, 0))
    if LIVES >= 3:
        LIVES_txt = font.render(f"LIVES: {LIVES}", True, GREEN)
        screen.blit(LIVES_txt, (3, 40))
    if LIVES == 2:
        LIVES_txt = font.render(f"LIVES: {LIVES}", True, YELLOW)
        screen.blit(LIVES_txt, (3, 40))
    if LIVES == 1:
        LIVES_txt = font.render(f"LIVES: {LIVES}", True, RED)
        screen.blit(LIVES_txt, (3, 40))
    pygame.display.update()


# Gameloop 
def main():
    # Rects 
    panda_rect = pygame.Rect(panda_x, panda_y, panda_width, panda_height)
    bamboo_rect = pygame.Rect(bamboo_x, bamboo_y, bamboo_size, bamboo_size)
    steak_rect = pygame.Rect(steak_x, steak_y, steak_size, steak_size)
    B_VELOCITY = 4
    SCORE = 0
    LIVES = 3
    pygame.mixer.music.play(-1)
    running = True
    while running:
        clock.tick(FPS)
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                running = False
        if pygame.Rect.colliderect(steak_rect, panda_rect):
            steak_rect.x = random.randrange(1, 1001 - 64)
            steak_rect.y = -64
            LIVES -= 1
        if pygame.Rect.colliderect(bamboo_rect, panda_rect):
            bamboo_collected.play()
            bamboo_rect.x = random.randrange(1, 1001 - 64)
            bamboo_rect.y = -64
            SCORE += 1
            B_VELOCITY += 0.01
        if pygame.Rect.colliderect(bamboo_rect, steak_rect):
            bamboo_rect.x = random.randrange(1, 1001 - 64)
            bamboo_rect.y = -64
            steak_rect.x = random.randrange(1, 1001)
            steak_rect.y = -64
        if steak_rect.y > 500:
            steak_rect.x = random.randrange(1, 1001)
            steak_rect.y = -64
        if bamboo_rect.y > 500:
            lost_life.play()
            bamboo_rect.x = 872
            bamboo_rect.y = -64
            LIVES -= 1    
        if LIVES == 0:
            lost.play()
            pygame.time.wait(5000)
            running = False
        if SCORE / 50 == int(SCORE / 50) and SCORE / 50 != 0:
            bamboo_collected.play()
            LIVES += 1
            SCORE += 1
        if B_VELOCITY > 6.9:
            B_VELOCITY = 6.9
        draw(panda_rect, bamboo_rect, steak_rect, SCORE, LIVES, B_VELOCITY)


# Stops from automatically running if imported
if __name__ == "__main__":
    main()